/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bulletinspace.bulletindao;



import static com.bulletinspace.bulletindao.Employees_1_.firstname;
import static com.bulletinspace.bulletindao.Employees_1_.lastname;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author lyndenmarshall
 */

@PropertySource("classpath:/redcap.properties")
@Component
public class EmployeeDao implements Redshift{
  

    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public void addEmployees_1(Employees_1 employees_1) {

    }


    public <T> void insert(T data) {
        Employees_1 employees_1 = (Employees_1) data;
        this.jdbcTemplate.update(
                "insert into employees (empId, firstname,lastname,socialsecurity,salary) values (?, ?,?,?,?)",
                employees_1.getEmpid(), employees_1.getFirstname(),employees_1.getLastname(),employees_1.getSocialsecurity(),employees_1.getSalary());
    }

    public <T> void insertBatch(List<T> data) {
        final List<Employees_1> employees = (List<Employees_1>) data;

        String sql = "insert into employees (empId, firstname,lastname,socialsecurity,salary) values (?, ?,?,?,?)";

        this.jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Employees_1 employees_1 = employees.get(1);
                ps.setLong(1, employees_1.getEmpid());
                ps.setString(2, employees_1.getFirstname());
                ps.setString(3, employees_1.getLastname() );
                ps.setLong(4, employees_1.getSocialsecurity() );
                ps.setInt(5, employees_1.getSalary() );
                
            }

            @Override
            public int getBatchSize() {
                return employees.size();
            }
        });
    }
   public static void main(String[] args)
    {
        ApplicationContext context = new ClassPathXmlApplicationContext(
				"daoConfiguration.xml");
        EmployeeDao employeeDao = (EmployeeDao)context.getBean("EmployeeDao");
        Employees_1 employees_1 = new Employees_1();
        employees_1.setEmpid(Short.MIN_VALUE);
        employees_1.setFirstname("Jason");
        employees_1.setLastname("Williams");
        employees_1.setSocialsecurity(433333349);
        employees_1.setSalary(62000);
       
        
       Employees_1.insert(employees_1);
    
    }
}
