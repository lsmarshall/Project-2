/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bulletinspace.bulletindao;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author lyndenmarshall
 */
@Entity
@Table(name = "EMPLOYEES", catalog = "", schema = "LSMARSHALL")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Employees_1.findAll", query = "SELECT e FROM Employees_1 e")
    , @NamedQuery(name = "Employees_1.findByEmpid", query = "SELECT e FROM Employees_1 e WHERE e.empid = :empid")
    , @NamedQuery(name = "Employees_1.findByFirstname", query = "SELECT e FROM Employees_1 e WHERE e.firstname = :firstname")
    , @NamedQuery(name = "Employees_1.findByLastname", query = "SELECT e FROM Employees_1 e WHERE e.lastname = :lastname")
    , @NamedQuery(name = "Employees_1.findBySocialsecurity", query = "SELECT e FROM Employees_1 e WHERE e.socialsecurity = :socialsecurity")
    , @NamedQuery(name = "Employees_1.findBySalary", query = "SELECT e FROM Employees_1 e WHERE e.salary = :salary")})
public class Employees_1 implements Serializable {

    private static final long serialVersionUID = 1L;

    static void insert(Employees_1 employees_1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "EMPID", nullable = false)
    private Short empid;
    @Size(max = 25)
    @Column(name = "FIRSTNAME", length = 25)
    private String firstname;
    @Size(max = 25)
    @Column(name = "LASTNAME", length = 25)
    private String lastname;
    @Column(name = "SOCIALSECURITY")
    private Long socialsecurity;
    @Column(name = "SALARY")
    private Integer salary;

    public Employees_1() {
    }

    public Employees_1(Short empid) {
        this.empid = empid;
    }

    public Short getEmpid() {
        return empid;
    }

    public void setEmpid(Short empid) {
        this.empid = empid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Long getSocialsecurity() {
        return socialsecurity;
    }

    public void setSocialsecurity(Long socialsecurity) {
        this.socialsecurity = socialsecurity;
    }

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (empid != null ? empid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employees_1)) {
            return false;
        }
        Employees_1 other = (Employees_1) object;
        if ((this.empid == null && other.empid != null) || (this.empid != null && !this.empid.equals(other.empid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.bulletinspace.bulletindao.Employees_1[ empid=" + empid + " ]";
    }

    Employees_1 get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Employees_1 get() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setSocialsecurity(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
