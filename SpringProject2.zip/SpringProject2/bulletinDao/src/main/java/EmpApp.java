
import com.bulletinspace.bulletindao.Employees_1;
import javax.annotation.Resource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lyndenmarshall
 */
public class EmpApp {
    
    public static void main( String[] args )
    {
    	ApplicationContext context =
    	  new ClassPathXmlApplicationContext(new String[] {"employee.txt"});

    	Employees_1 empl = (Employees_1)context.getBean("employees_1");
        boolean emp1 = false;
    	System.out.println(emp1);
        
        Resource resource = appContext.getResource("file:com.bulletinspace.bulletindao/Users/lyndenmarshall/NetBeansProjects/SpringProject2/bulletinDao/src/main/java/com/bulletinspace/bulletindao/employee.txt");

    }
}

